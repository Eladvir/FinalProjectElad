#include <stdlib.h>     //exit()
#include <signal.h>     //signal()
#include <time.h>
#include "ADS1256.h"
#include <stdio.h>
#include <math.h>
#include "calibration.h"

// ADC channels
#define VOLTAGE_CHAN (0)
#define CURRENT_CHAN (1)
#define LEAKAGE_CHAN (2)
#define BATTERY_CHAN (3)

void Handler(int signo)
{
    DEV_ModuleExit();
    exit(0);
}

double getSample(int channel, double bias, double coefficient) {
    double val = ADS1256_GetChannalValue(channel) * 5.0 / 0x7fffff + bias;
    if (val < 0) return 0;
    return val * coefficient;
}

int main(void)
{
    struct timespec ts;
    struct timespec sleeptime = {0, 10000000};

    char *names[] = {"voltage", "current", "leakage", "battery"};
    int channels[] = {VOLTAGE_CHAN, CURRENT_CHAN, LEAKAGE_CHAN, BATTERY_CHAN};
    float biases[] = {VOLTAGE_BIAS, CURRENT_BIAS, LEAKAGE_BIAS, BATTERY_BIAS};
    float coefficients[] = {VOLTAGE_COEF, CURRENT_COEF, LEAKAGE_COEF, BATTERY_COEF};

    int i;

    DEV_ModuleInit();

    // Exception handling:ctrl + c
    signal(SIGINT, Handler);

    if(ADS1256_init() == 1) {
        DEV_ModuleExit();
        exit(0);
    }

    ADS1256_ConfigADC(ADS1256_GAIN_1, ADS1256_100SPS, 1);

    while(1) {
        for(i = 0; i < 4; i++) {
            timespec_get(&ts, TIME_UTC);
            printf("{\"ts\":%ld.%09ld,\"sensor\":\"%s\",\"value\":%f}\n", ts.tv_sec, ts.tv_nsec, names[i], getSample(channels[i], biases[i], coefficients[i]));
            nanosleep(&sleeptime, NULL);
        }
    }

    return 0;
}
