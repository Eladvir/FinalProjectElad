USER=pi

cd /home/$USER

apt-get -y install wiringpi python3-smbus libusb-1.0-0-dev python3-pip git
python3 -m pip install -U pip setuptools wheel
python3 -m pip install gunicorn

sudo -u $USER git clone https://github.com/mvp/uhubctl.git
cd uhubctl
sudo -u $USER make
make install
cd ~

sudo -u $USER git clone https://github.com/zeevro/sem.git
cd sem
sudo -u $USER make -C adc
python3 -m pip install -e .
systemctl link systemd/*
cd systemd
systemctl enable --now *
cd ~
