#!/bin/sh
export FLASK_APP="$(dirname "$0")/src/sem.app:app"
export FLASK_DEBUG=1
flask run -h 0.0.0.0 -p 5000 --with-threads
