from setuptools import setup


setup(
    name='sem',
    version='0.0.1',
    url='https://github.com/zeevro/sem',
    download_url='https://github.com/zeevro/sem/archive/master.zip',
    author='Zeev Rotshtein',
    author_email='zeevro@gmail.com',
    maintainer='Zeev Rotshtein',
    maintainer_email='zeevro@gmail.com',
    license=None,
    zip_safe=True,
    package_dir={
        '': 'src',
    },
    packages=[
        'sem',
    ],
    install_requires=[
        'appdirs',
        'automationhat',
        'arrow',
        'click',
        'dirtyjson',
        'flask',
        'pymodbus',
        'pyserial',
        'sdnotify',
        'tinydb',
        'websocket-client',
    ],
)
