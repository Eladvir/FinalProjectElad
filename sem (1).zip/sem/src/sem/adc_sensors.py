import os
import subprocess

import click

from .utils import SensorsReporter


@click.command()
@click.option('-h', '--host', default='127.0.0.1')
@click.option('-p', '--port', default=12345)
@click.option('-c', '--command', default=os.path.abspath(os.path.join(os.path.dirname(__file__), '../../adc/bin/adc_poller')))
@click.option('-D', '--debug', is_flag=True)
def main(host, port, command, debug):
    send = SensorsReporter(host, port, debug).send

    prog = subprocess.Popen(command, stdout=subprocess.PIPE)
    while prog.poll() is None:
        send(prog.stdout.readline())


if __name__ == "__main__":
    main()
