import time

from flask import Flask, request, jsonify, redirect, render_template, url_for

from sem.settings import load_alerts, load_settings, save_settings, update_alerts_from_settings
from sem.utils import sensors_manager_request


app = Flask(__name__)


SENSOR_UNITS = {
    'voltage': 'V',
    'current': 'A',
    'leakage': 'mA',
    'battery': 'V',
}

SENSOR_FORMATS = [
    ('voltage', '{:.0f}' + SENSOR_UNITS['voltage']),
    ('current', '{:f}' + SENSOR_UNITS['current']),
    ('leakage', '{:f}' + SENSOR_UNITS['leakage']),
    ('battery', '{:f}' + SENSOR_UNITS['battery']),
]


@app.template_filter()
def op_ligature(s):
    return{'>=': '≥', '<=': '≤'}.get(s, s)


@app.template_filter()
def timestamp(ts):
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ts))


def sensors_for_dashboard():
    sensor_values = sensors_manager_request('sensor_values', default={})

    return [
        {
            'name': sensor.title(),
            'value': fmt.format(sensor_values[sensor]) if sensor in sensor_values else '???'
        }
        for sensor, fmt in SENSOR_FORMATS
    ]


@app.route('/')
def dashboard():
    return render_template('dashboard.html', sensors=sensors_for_dashboard())


@app.route('/sensors')
def sensors():
    return jsonify(sensors_for_dashboard())


@app.route('/alerts')
def alerts():
    raised_alerts = sensors_manager_request('raised_alerts', default=[])
    alert_names = {alert['id']: alert['name'] for alert in load_alerts()}
    return render_template('alerts.html', alerts=[alert_names[a['id']] for a in raised_alerts])


@app.route('/logs')
def logs():
    return render_template('logs.html', records=[])


@app.route('/settings', methods=['GET', 'POST'])
def settings():
    alerts = load_alerts()

    if request.method == 'GET':
        settings = load_settings()
        update_alerts_from_settings(alerts, settings)
        return render_template('settings.html', alerts=alerts, settings=settings, units=SENSOR_UNITS)

    d = dict(request.form)

    for k, v in d.items():
        if k.endswith('enabled'):
            d[k] = True
        else:
            try:
                d[k] = float(v)
            except ValueError:
                pass
    for alert in alerts:
        d.setdefault(f'alert_{alert["id"]}_enabled', False)

    save_settings(d)

    sensors_manager_request('reload_settings')

    return redirect(url_for('settings'))
