import automationhat
import click

from .utils import SingleSensorReporter, get_sleep_function


@click.command()
@click.option('-h', '--host', default='127.0.0.1')
@click.option('-p', '--port', default=12345)
@click.option('-S', '--sensor', default='battery')
@click.option('-c', '--channel', default=0)
@click.option('-d', '--digital', is_flag=True)
@click.option('-R', '--poll-rate', default=10)
@click.option('-D', '--debug', is_flag=True)
def main(host, port, sensor, channel, digital, poll_rate, debug):
    report = SingleSensorReporter(sensor, host, port, debug).report
    sleep = get_sleep_function(poll_rate)

    reader = (automationhat.input if digital else automationhat.analog)[channel]

    while 1:
        report(reader.read())
        sleep()


if __name__ == "__main__":
    main()
