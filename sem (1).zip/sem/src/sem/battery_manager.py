import subprocess
import time

from sem.utils import log, sensors_manager_request


SLEEP_TIME = 30  # 30 seconds
INVALID_THRESHOLD = 8
POWEROFF_THRESHOLD = 10


def handle_low_battery():
    subprocess.call('date >> /tmp/sem-poweroff.log', shell=True)


def main():
    while 1:
        sensor_values = sensors_manager_request('sensor_values', default={})
        battery_value = sensor_values.get('battery', None)
        if not battery_value:  # Zero or None
            log('Battery level unknown!!')

        elif battery_value < INVALID_THRESHOLD:
            log('Battery level too low!')

        elif battery_value < POWEROFF_THRESHOLD:
            log('LOW BATTERY!!!')
            handle_low_battery()

        time.sleep(SLEEP_TIME)


if __name__ == "__main__":
    main()
