import subprocess
import time


from sem.utils import log


SLEEP_TIME = 3 * 60  # 3 minutes


class CallOK(Exception):
    pass


def fail_on_success(cmd):
    try:
        subprocess.check_call(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        raise CallOK()
    except subprocess.CalledProcessError as e:
        return e.returncode


def main():
    fail_on_success(r"ifconfig | grep asdf")
    while 1:
        try:
            fail_on_success(r"ping -c 2 8.8.8.8")
            fail_on_success(r"ifconfig wlan0 | grep 'inet 192\.168\.100\.")
            fail_on_success(r"ping -c 2 192.168.100.1")
        except CallOK:
            continue
        except Exception as e:
            log(f'{e.__class__.__name__}: {e}')
        else:
            log('Cellular died')
            subprocess.call(['uhubctl', '-l', '2', '-a', 'cycle'])
        finally:
            time.sleep(SLEEP_TIME)


if __name__ == "__main__":
    main()
