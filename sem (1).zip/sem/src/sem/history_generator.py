from base64 import b64encode
import lzma
import random
import time

import arrow
import click


from sem.utils import jsonify


RANDOM_RANGES = {
    'voltage': (215, 232),
    'current': (8, 15),
    'leakage': (0, 7),
    'battery': (12, 14),
}


@click.command()
@click.option('-s', '--start', default=int(time.time()) - 600)
@click.option('-l', '--length', default=600)
@click.option('-i', '--interval', default=1)
@click.option('-z', '--compress', is_flag=True)
def main(start, length, interval, compress):
    data_points = []
    for ts in range(start, start + length, interval):
        record = {'timestamp': arrow.get(ts).strftime('%Y-%m-%d %H:%M:%S.%f')}
        for sensor, rng in RANDOM_RANGES.items():
            record[sensor] = random.randint(*rng)
        data_points.append(record)

    if compress:
        data_points = b64encode(lzma.compress(jsonify(data_points).encode())).decode('latin1')

    print(jsonify(
        {
            'method': 'DataHistory',
            'data': {
                'data-points': data_points,
            },
        }
    ))


if __name__ == "__main__":
    main()
