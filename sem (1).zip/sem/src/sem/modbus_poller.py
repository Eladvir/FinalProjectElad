import sys

import click
from pymodbus.client.sync import ModbusSerialClient

from .utils import SingleSensorReporter, get_sleep_function


@click.command()
@click.option('-h', '--host', default='127.0.0.1')
@click.option('-p', '--port', default=12345)
@click.option('-S', '--sensor', default='current')
@click.option('-s', '--serial-port', default='/dev/ttyUSB0')
@click.option('-b', '--baud-rate', default=9600)
@click.option('-a', '--sensor-address', default=1)
@click.option('-r', '--register-address', default=0x11)
@click.option('-d', '--divisor', default=100)
@click.option('-R', '--poll-rate', default=0)
@click.option('-D', '--debug', is_flag=True)
def main(host, port, sensor, serial_port, baud_rate, sensor_address, register_address, divisor, poll_rate, debug):
    report = SingleSensorReporter(sensor, host, port, debug).report
    sleep = get_sleep_function(poll_rate)

    with ModbusSerialClient('rtu', port=serial_port, baudrate=baud_rate) as modbus:
        while 1:
            resp = modbus.read_holding_registers(register_address, unit=sensor_address)
            if isinstance(resp, Exception):
                print(resp, file=sys.stderr)
                continue
            report(resp.registers[0] / divisor)
            sleep()


if __name__ == "__main__":
    main()
