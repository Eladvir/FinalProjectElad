## Sensor → Server

### DataHistory
```json
{
    "method": "DataHistory",
    "data": {
        "data-points": [
            {
                "timestamp": "1970-01-01 12:34:56.789",
                "voltage": 230,
                "current": 3.47,
                "leakage": 0.005,
                "battery": 13.8,
            },
            {
                "timestamp": "1970-01-01 13:04:52.364",
                "voltage": 230,
                "current": 3.62,
                "leakage": 0.004,
                "battery": 13.9,
            }
        ]
    }
}
```

Compressed data history is provisional and not yet implemented in server-side
```json
{
    "method": "DataHistory",
    "data": {
        "data-points": "< base64 encoded LZMA compressed JSON list >"
    }
}
```

### RealTimeData
```json
{
    "method": "RealTimeData",
    "requestor": "name@example.com",
    "data": {
        "voltage": 230,
        "current": 3.47,
        "leakage": 0.005,
        "battery": 13.8,
    }
}
```

### Alert
```json
{
    "method": "Alert",
    "data": {
        "timestamp": "1970-01-01 12:34:56.789",
        "id": "overcurrent",
        "value": 17,
        "duration": 1.8
    }
}
```

```json
{
    "method": "Alert",
    "data": {
        "timestamp": "1970-01-01 12:34:56.789",
        "id": "overcurrent",
        "reset": true
    }
}
```

### SettingsAccepted
```json
{
    "method": "SettingsAccepted"
}
```


## Server → Sensor

### GetRealTime
```json
{
    "method": "GetRealTime",
    "requestor": "name@example.com"
}
```

### ChangeSettings
```json
{
    "method": "ChangeSettings",
    "data": "Settings to be changed. TBD."
}
```