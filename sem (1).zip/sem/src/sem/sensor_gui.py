import sys
import threading
import time
import tkinter

import click

from .utils import SensorsReporter, get_sleep_function


sensor_values = {}


SENSORS = [
    ('voltage', 0, 300, 1, 230),
    ('current', 0, 60, 0.1, 0),
    ('leakage', 0, 20, 0.1, 0),
    ('battery', 0, 15, 0.01, 14),
]


def updater_thread(host, port, rate):
    print(f'Connecting to {host}:{port}', file=sys.stderr)

    sleep = get_sleep_function(rate)

    while 1:
        try:
            report = SensorsReporter(host, port).report

            while 1:
                sleep()
                for sensor, value in sensor_values.items():
                    report(sensor, value)
        except Exception as e:
            print(f'ERROR! {e}', file=sys.stderr)

        time.sleep(1.5)


def change_sensor(name):
    def changer(value):
        sensor_values[name] = float(value)
    return changer


@click.command()
@click.option('-h', '--host', default='127.0.0.1')
@click.option('-p', '--port', default=12345)
@click.option('-r', '--rate', default=10)
@click.option('-O', '--only')
def main(host, port, rate, only):
    top = tkinter.Tk()
    top.title('SEM Sensors')


    if only:
        for sensor in SENSORS:
            if sensor[0] == only:
                sensors = [sensor]
                break
        else:
            click.echo('Bad sensor in -O/--only!')
            return
    else:
        sensors = SENSORS

    for sensor, _, _, _, value in sensors:
        sensor_values[sensor] = value

    for name, minval, maxval, step, initval in sensors:
        scale = tkinter.Scale(top, takefocus=True, label=name.title(), orient=tkinter.HORIZONTAL, length=300, from_=minval, to=maxval, resolution=step, command=change_sensor(name))
        scale.pack(fill=tkinter.X, expand=True)
        scale.set(initval)

    threading.Thread(target=updater_thread, args=(host, port, rate), daemon=True).start()

    top.mainloop()


if __name__ == "__main__":
    main()
