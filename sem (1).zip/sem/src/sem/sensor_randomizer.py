import random
import sys

import click

from .utils import SensorsReporter, get_sleep_function


SENSORS = {
    'voltage': (230, 2),
    'current': (5, 5),
    'leakage': (0.7, 0.7),
    'battery': (13, 1.5),
}


def get_next_value(v, c, r):
    vmax = c + r
    vmin = c - r

    max_change = r / 5

    dmin = max(-max_change, vmin - v)
    dmax = min(max_change, vmax - v)

    d = random.triangular(dmin, dmax, 0)

    # print(f'v={v} vr={vmin}:{vmax} dr={dmin}:{dmax} d={d}')

    return v + d


@click.command()
@click.option('-h', '--host', default='127.0.0.1')
@click.option('-p', '--port', default=12345)
@click.option('-r', '--rate', default=10)
def main(host, port, rate):
    print(f'Connecting to {host}:{port}', file=sys.stderr)

    try:
        report = SensorsReporter(host, port).report
    except Exception as e:
        print(f'ERROR! Could not connect to server! {e}', file=sys.stderr)
        return 1

    sensor_values = {k: [c, c, r] for k, (c, r) in SENSORS.items()}

    sleep = get_sleep_function(rate)

    while 1:
        sleep()
        for sensor, values in sensor_values.items():
            v = get_next_value(*values)
            sensor_values[sensor][0] = v
            report(sensor, v)


if __name__ == "__main__":
    sys.exit(main())
