from base64 import b64encode
from collections import defaultdict
import json
import lzma
import operator
import socket
from socketserver import StreamRequestHandler
import threading
import time
import traceback

import sdnotify
from tinydb import where
import websocket

from sem.settings import load_alerts, load_settings, update_alerts_from_settings, SENSORS_MANAGER_DB_PATH, SERVER_CONFIG_PATH
from sem.utils import DaemonicThreadingTCPServer, RobustTinyDB, json_timestamp, jsonify, log


COMPRESS_HISTORY = False


alert_handlers = {}
alert_handlers_by_id = {}  # This is to allow hacky alert dependencies (no_voltage/undervoltage)

sensor_values = {}
sensor_values_store_op = {
    'current': (max, float('-inf')),
    'leakage': (max, float('-inf')),
    None: (lambda old, new: new, 0),
}
sensor_values_old = {}

db = RobustTinyDB(SENSORS_MANAGER_DB_PATH)
alerts_table = db.table('alerts', cache_size=0)
raised_alerts_table = db.table('raised_alerts', cache_size=0)
history_table = db.table('sensors', cache_size=0)
db_lock = threading.Lock()

last_history_send_time = 0

server_ws = None

alerts_broadcast_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


def send_all_alert_messages(app=None):
    if app is None:
        app = server_ws

    if len(alerts_table):
        with db_lock:
            for msg in alerts_table.all():
                app.send(jsonify(
                    {
                        'method': 'Alert',
                        'data': msg
                    }
                ))
                alerts_table.remove(doc_ids=[msg.doc_id])


def post_alert_message(alert_id, **params):
    msg = dict(
        timestamp=json_timestamp(),
        id=alert_id,
        **params,
    )
    alerts_broadcast_sock.sendto(jsonify(msg).encode(), ('127.0.0.1', 12347))
    with db_lock:
        alerts_table.insert(msg)
    try:
        send_all_alert_messages()
    except Exception:
        log('ERROR! Failed to send alert messages.')
        log(traceback.format_exc())


class BaseAlert:
    alert_type = None

    subclasses = []

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls.subclasses.append(cls)

    def __init__(self, id, sensor, **kw):
        self.id = id
        self.sensor = sensor

    def raise_alert(self, record):
        # TODO: Don't use time.time() for duration.

        log(f'ALERT raised! {self.id} {jsonify(record)}')

        with db_lock:
            raised_alerts_table.upsert({'id': self.id, 'raised': True}, where('id') == self.id)

        post_alert_message(self.id, value=record['value'], duration=time.time() - record['ts'])

        ### HACK!!! ### NOT THREAD-SAFE!!! ### This prevents the 'undervoltage' alert when 'no_voltage' is already raised
        if self.id == 'no_voltage' and alert_handlers_by_id['undervoltage']._raised:
            alert_handlers_by_id['undervoltage'].flip_state(record)

    def clear_alert(self, record):
        log(f'ALERT cleared. {self.id} {jsonify(record)}')
        with db_lock:
            removed_ids = raised_alerts_table.remove(where('id') == self.id)
        if removed_ids:
            post_alert_message(self.id, reset=True)

    def set_raised(self, is_raised):
        raise NotImplementedError

    def process_record(self, record):
        pass


class ThresholdAlert(BaseAlert):
    alert_type = 'threshold'

    OPERATIONS = {
        '=': operator.eq,
        '!=': operator.ne,
        '>': operator.gt,
        '<': operator.lt,
        '>=': operator.ge,
        '<=': operator.le,
    }

    REVERSE_OPERATIONS = {
        operator.eq: operator.ne,
        operator.ne: operator.eq,
        operator.gt: operator.le,
        operator.lt: operator.ge,
        operator.ge: operator.lt,
        operator.le: operator.gt,
    }

    OPERATIONS_STR = dict(map(reversed, OPERATIONS.items()))

    def __init__(self, id, sensor, op, value, duration, **kw):
        super().__init__(id, sensor)

        self.op = self.OPERATIONS[op]
        self.value = float(value)
        self.duration = duration

        self._trigger_record = None
        self._raised = False

    def set_raised(self, is_raised):
        self._raised = bool(is_raised)
        if self._raised:
            self.op = self.REVERSE_OPERATIONS[self.op]

    def _check(self, n):
        return self.op(float(n), self.value)

    def flip_state(self, record):
        try:
            if self._raised:
                self.clear_alert(record)
            else:
                self.raise_alert(record)
        finally:
            self.op = self.REVERSE_OPERATIONS[self.op]
            self._raised = not self._raised

    def process_record(self, record):
        ### HACK!!! ### NOT THREAD-SAFE!!! ### This prevents the 'undervoltage' alert when 'no_voltage' is already raised
        if self.id == 'undervoltage' and alert_handlers_by_id['no_voltage']._raised:
            return

        record_triggers = self._check(record['value'])

        if not record_triggers:
            self._trigger_record = None
            return

        if self._trigger_record is None:
            self._trigger_record = record

        if record['ts'] >= self._trigger_record['ts'] + self.duration:  # Cannot be "elif" or duration=0 will not work
            self.flip_state(self._trigger_record)

    def __str__(self):
        op = self.OPERATIONS_STR[self.REVERSE_OPERATIONS[self.op] if self._raised else self.op]
        return f'[{self.id}]{self.__class__.__name__}({self.sensor} {op} {self.value} for {self.duration}s)'


class RepeatedThresholdAlert(ThresholdAlert):
    alert_type = 'threshold_repeat'

    def __init__(self, id, sensor, op, value, duration, repeats, **kw):
        super().__init__(id, sensor, op, value, duration=0)
        self.repeats = repeats
        self.repeat_duration = duration

        self._trigger_records = []
        self._clear_record = None
        self._meta_raised = False  # We can't use ThresholdAlert._raised

    def raise_alert(self, record):
        time_threshold = record['ts'] - self.repeat_duration
        while self._trigger_records and self._trigger_records[0]['ts'] < time_threshold:
            self._trigger_records.pop(0)
        self._trigger_records.append(record)

        self._clear_record = None

        if not self._meta_raised:
            if len(self._trigger_records) >= self.repeats:
                super().raise_alert(self._trigger_records[0])
                self._meta_raised = True

    def clear_alert(self, record):
        if self._clear_record is None:
            self._clear_record = record

    def set_raised(self, is_raised):
        super().set_raised(is_raised)
        self._meta_raised = bool(is_raised)

    def process_record(self, record):
        super().process_record(record)

        if self._meta_raised:
            if self._clear_record is not None and record['ts'] >= self._clear_record['ts'] + self.repeat_duration:
                super().clear_alert(self._clear_record)
                self._clear_record = None
                self._meta_raised = False

    def __str__(self):
        op = self.OPERATIONS_STR[self.REVERSE_OPERATIONS[self.op] if self._raised else self.op]
        return f'[{self.id}]{self.__class__.__name__}({self.sensor} {op} {self.value} {self.repeats} times in {self.repeat_duration}s)'


def build_alert_handlers():
    alerts_data = update_alerts_from_settings(load_alerts(), load_settings())

    alert_classes = {cls.alert_type: cls for cls in BaseAlert.subclasses}

    ret = defaultdict(list)
    for alert_data in alerts_data:
        if not alert_data['enabled']:
            continue
        try:
            handler = alert_classes[alert_data['type']](**alert_data)
            handler.set_raised(raised_alerts_table.count((where('id') == alert_data['id']) & (where('raised') == True)) > 0)
            ret[alert_data['sensor']].append(handler)
            log(f'Built alert handler: {handler}')
        except Exception:
            log('Could not build alert!')
            log(json.dumps(alert_data, indent=2, separators=(',', ': ')))
            traceback.print_exc()

    return dict(ret)


class SensorsHandler(StreamRequestHandler):
    def handle(self):
        for line in self.rfile:
            line = line.strip()
            try:
                record = json.loads(line)
            except Exception:
                log(f'ERROR! Bad JSON on sensor feed: {line}')
                continue

            sensor = record['sensor']
            store_op, init_val = sensor_values_store_op.get(sensor, sensor_values_store_op[None])
            sensor_values[sensor] = store_op(sensor_values.get(sensor, init_val), record['value'])

            for handler in alert_handlers.get(sensor, []):
                try:
                    handler.process_record(record)
                except Exception:
                    log('ERROR!', handler, record)
                    traceback.print_exc()


class GuiHandler(StreamRequestHandler):
    def handle(self):
        req = self.rfile.readline().decode().strip().split(maxsplit=1)
        if not req:
            return

        resp = None

        if req[0] == 'reload_settings':
            resp = 'OK'
            reload_alerts()

        elif req[0] == 'sensor_values':
            resp = get_real_time_values()

        elif req[0] == 'raised_alerts':
            resp = raised_alerts_table.all()

        if resp is not None:
            self.request.send((jsonify(resp) + '\n').encode())


def reload_alerts():
    alert_handlers.clear()
    alert_handlers.update(build_alert_handlers())

    alert_handlers_by_id.clear()
    for l in alert_handlers.values():
        for handler in l:
            alert_handlers_by_id[handler.id] = handler


def send_history(app=None):
    global last_history_send_time

    if app is None:
        app = server_ws

    log(f'send_history() called. {time.time() - last_history_send_time:.0f}s since last successful send. {len(history_table)} records in buffer.')

    if len(history_table):
        with db_lock:
            data_points = history_table.all()
            if COMPRESS_HISTORY:
                data_points = b64encode(lzma.compress(jsonify(data_points).encode())).decode('latin1')
            app.send(jsonify(
                {
                    'method': 'DataHistory',
                    'data': {
                        'data-points': data_points,
                    },
                }
            ))
            history_table.truncate()
        last_history_send_time = time.time()


def history_sender(interval):
    while 1:
        time.sleep(interval)
        try:
            send_history()
        except Exception:
            log(traceback.format_exc())


def load_server_config():
    with open(SERVER_CONFIG_PATH) as f:
        config = json.load(f)

    return config


def connect_websocket(stop_event):
    global server_ws

    server_config = load_server_config()

    def on_open(app):
        log('Connected to server.')

        try:
            send_all_alert_messages(app)
        except Exception:
            log('send_all_alert_messages() failed!')
            log(traceback.format_exc())

        if time.time() >= last_history_send_time + server_config['interval']:
            try:
                send_history(app)
            except Exception:
                log('send_history() failed!')
                log(traceback.format_exc())

    def on_close(app, code, reason):
        log(f'Disconnected from server! code={code} reason={reason}')

    def on_error(app, e):
        log(f'Server socket error!!! {e.__class__.__name__}: {e}')

    while not stop_event.is_set():
        server_ws = websocket.WebSocketApp(
            server_config['url'],
            header={
                'X-Device-Id': server_config['device_id'],
            },
            on_message=server_message,
            on_open=on_open,
            on_close=on_close,
            on_error=on_error,
        )

        server_ws.run_forever(ping_interval=30)
        server_ws.close()
        time.sleep(3)


def get_real_time_values():
    temp_values = sensor_values_old.copy()
    temp_values.update(sensor_values)

    if 'leakage' in temp_values and temp_values['leakage'] < 1:
        temp_values['leakage'] = 0

    if 'current' in temp_values and temp_values['current'] < 0.25:
        temp_values['current'] = 0

    return temp_values


def server_message(app, msg):
    # TODO: Add handler for ChangeSettings
    log('Server sent:', msg)
    data = json.loads(msg)
    cmd = data.get('method', None)
    if cmd == 'GetRealTime':
        app.send(jsonify(
            {
                'method': 'RealTimeData',
                'requestor': data.get('requestor', None),
                'data': get_real_time_values(),
            }
        ))


def main():
    reload_alerts()

    sensors_server = DaemonicThreadingTCPServer(('', 12345), SensorsHandler)
    sensors_thread = threading.Thread(target=sensors_server.serve_forever, daemon=True)

    gui_server = DaemonicThreadingTCPServer(('', 12346), GuiHandler)
    gui_thread = threading.Thread(target=gui_server.serve_forever, daemon=True)

    sensors_thread.start()
    gui_thread.start()

    websocket_stop_event = threading.Event()
    websocket_thread = threading.Thread(target=connect_websocket, args=(websocket_stop_event,), daemon=True)
    websocket_thread.start()

    server_config = load_server_config()
    sender_thread = threading.Thread(target=history_sender, args=(server_config['interval'],), daemon=True)
    sender_thread.start()

    sysd = sdnotify.SystemdNotifier()

    log('Started.')
    sysd.notify('READY=1')

    try:
        while 1:
            if sensor_values:
                with db_lock:
                    history_table.insert(dict(timestamp=json_timestamp(), **sensor_values))
                for sensor in sensor_values_store_op:
                    # NOTE: battery_manager.py counts on sensor_values['battery'] so we don't want to clear it.
                    if sensor is None:
                        continue
                    old_value = sensor_values.pop(sensor, None)
                    if old_value is not None:
                        sensor_values_old[sensor] = old_value
            time.sleep(1)
    except KeyboardInterrupt:
        log('Ctrl-C')

    sysd.notify('STOPPING=1')

    websocket_stop_event.set()
    server_ws.close()
    sensors_server.shutdown()
    sensors_server.server_close()
    gui_server.shutdown()
    gui_server.server_close()

    log('Finished.')


if __name__ == "__main__":
    main()
