import json
import sys

import click

from sem.settings import SERVER_CONFIG_PATH


@click.command()
@click.option('-u', '--url')
@click.option('-d', '--device-id')
@click.option('-i', '--interval', type=click.INT)
def main(url, device_id, interval):
    try:
        with open(SERVER_CONFIG_PATH) as f:
            config = json.load(f)
    except Exception:
        config = {}

    dirty = False

    if url:
        config['url'] = url
        dirty = True

    if device_id:
        config['device_id'] = device_id
        dirty = True

    if interval:
        config['interval'] = interval
        dirty = True
    else:
        config.setdefault('interval', 60 * 10)

    print('Current config:')
    json.dump(config, sys.stdout, indent=4, separators=(',', ': '))

    for k in ['url', 'device_id']:
        if not config.get(k, None):
            print(f'Missing "{k}" field!', file=sys.stderr)
            return

    if dirty:
        with open(SERVER_CONFIG_PATH, 'w') as f:
            json.dump(config, f, indent=4, separators=(',', ': '))


if __name__ == "__main__":
    main()
