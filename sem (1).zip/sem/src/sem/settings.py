import appdirs
import json
import os
import uuid


SETTINGS_PATH = os.path.join(appdirs.user_config_dir('sem', False), 'settings.json')
ALERTS_PATH = os.path.join(os.path.dirname(__file__), 'alerts.json')
SENSORS_MANAGER_DB_PATH = os.path.join(appdirs.user_data_dir('sem', False), 'sensors_manager_db.json')
SERVER_CONFIG_PATH = os.path.join(appdirs.user_config_dir('sem', False), 'server.json')


for path in (SETTINGS_PATH, ALERTS_PATH, SENSORS_MANAGER_DB_PATH):
    os.makedirs(os.path.dirname(path), exist_ok=True)


def _box_id_for_name():
    return ''.join(map('{:02X}'.format, uuid.getnode().to_bytes(6, 'big')))


def load_alerts():
    with open(ALERTS_PATH) as f:
        return json.load(f)


def load_settings():
    file_exists = False

    alerts = load_alerts()
    try:
        with open(SETTINGS_PATH) as f:
            settings = json.load(f)
        file_exists = True
    except FileNotFoundError:
        settings = {}

    for alert in alerts:
        prefix = f'alert_{alert["id"]}_'
        for k in ('value', 'duration', 'repeats'):
            if k in alert:
                settings.setdefault(f'{prefix}{k}', alert[k])
        settings.setdefault(f'{prefix}enabled', True)
        settings.setdefault(f'{prefix}repeats', 1)

    if not settings.get('box_name'):
        settings['box_name'] = f'sem_{_box_id_for_name()}'

    if not settings.get('box_uuid'):
        settings['box_uuid'] = f'sem-{uuid.uuid4()}'

    if not file_exists:
        save_settings(settings)

    return settings


def save_settings(settings):
    os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
    with open(SETTINGS_PATH, 'w') as f:
        json.dump(settings, f, indent=4, separators=(',', ': '), sort_keys=True)


def update_alerts_from_settings(alerts, settings):
    for alert in alerts:
        prefix = f'alert_{alert["id"]}_'
        for i in ('enabled', 'value', 'duration', 'repeats'):
            k = f'{prefix}{i}'
            if k in settings:
                alert[i] = settings[k]
    return alerts
