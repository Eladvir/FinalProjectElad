import json
import socket
import time

import automationhat

from sem.utils import log


def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('', 12347))

    while 1:
        alert = json.loads(sock.recv(4096))
        if alert.get('reset', False) or alert['id'] != 'shutdown':
            continue

        log('Shutdown alert received!')

        automationhat.relay[0].on()
        time.sleep(0.5)
        automationhat.relay[0].off()


if __name__ == "__main__":
    main()
