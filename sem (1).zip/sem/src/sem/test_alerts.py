from sem.sensors_manager import BaseAlert, ThresholdAlert, RepeatedThresholdAlert, alerts_table
from sem import sensors_manager


class DummyWS:
    @staticmethod
    def send(data):
        # print(data)
        pass


sensors_manager.server_ws = DummyWS()


def test_case(alert: BaseAlert, sensor_values):
    headline = f'Test {alert.__class__.__name__}'
    print()
    print(headline)
    print('-' * len(headline))

    records = [
        {
            'ts': t,
            'value': float(v)
        }
        for t, v in enumerate(sensor_values)
    ]
    for record in records:
        print(record)
        alert.process_record(record)


def main():
    try:
        test_case(
            ThresholdAlert('Threshold alert', 'sensor_name', '>=', 5, 3),
            [1, 1, 5, 5, 5, 1, 1, 1, 5, 5, 5, 5, 5, 5, 5, 1, 1, 5, 1, 2, 1, 1, 2],
        )

        test_case(
            RepeatedThresholdAlert('Repeated TH alert', 'sensor_name', '<', 5, 8, 3),
            [7, 7, 7, 4, 4, 7, 7, 7, 7, 7, 7, 7, 7, 4, 7, 4, 7, 7, 4, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7]
        )
    finally:
        alerts_table.truncate()


if __name__ == "__main__":
    main()
