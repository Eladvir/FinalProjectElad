import json
import socket
from socketserver import ThreadingTCPServer
import sys
import time
from typing import Dict, Any, Optional

import arrow
import dirtyjson
from tinydb.database import TinyDB
from tinydb.storages import JSONStorage


SOCK_BUF_SIZE = 4096


def log(*a, **kw):
    print(*a, **kw)
    sys.stdout.flush()


def json_timestamp(ts=None):
    if ts is None:
        a = arrow.get()
    else:
        a = arrow.get(ts)
    return a.strftime('%Y-%m-%d %H:%M:%S.%f')


def jsonify(o):
    return json.dumps(o, separators=(',', ':'))


def sensors_manager_request(op, *args, default=None):
    s = socket.socket()
    try:
        s.connect(('localhost', 12346))
        req = op
        if args:
            req += ' ' + ' '.join(args)
        s.send(f'{req}\n'.encode())
        resp = b''
        while 1:
            buf = s.recv(SOCK_BUF_SIZE)
            resp += buf
            if len(buf) < SOCK_BUF_SIZE:
                break
        resp = json.loads(resp)
    except Exception as e:
        print(f'ERROR! {e.__class__.__name__}: {e}')
        resp = default
    finally:
        s.close()

    return resp


class DaemonicThreadingTCPServer(ThreadingTCPServer):
    daemon_threads = True


class RobustJSONStorage(JSONStorage):
    def read(self) -> Optional[Dict[str, Dict[str, Any]]]:
        try:
            return super().read()
        except Exception:
            self._handle.seek(0)
            try:
                return dirtyjson.load(self._handle)
            except Exception:
                return None


class RobustTinyDB(TinyDB):
    default_storage_class = RobustJSONStorage


class DummySocket:
    def send(self, data):
        print(data)


class SensorsReporter:
    def __init__(self, host, port, debug=False):
        if debug:
            self._sock = DummySocket()
        else:
            self._sock = socket.socket()
            self._sock.connect((host, port))

        self.send = self._sock.send

    def report(self, sensor, value):
        record = {'ts': time.time(), 'sensor': sensor, 'value': value}
        self.send((jsonify(record)  + '\n').encode())


class SingleSensorReporter(SensorsReporter):
    def __init__(self, sensor, host, port, debug=False):
        super().__init__(host, port, debug)
        self._sensor = sensor

    def report(self, value):
        super().report(self._sensor, value)


def get_sleep_function(rate):
    if rate:
        sleep_time = 1 / rate
        def sleep_func():
            time.sleep(sleep_time)
    else:
        def sleep_func():
            pass
    return sleep_func