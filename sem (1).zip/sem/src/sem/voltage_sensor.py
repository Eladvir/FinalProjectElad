import sys

import click
import serial

from .utils import SingleSensorReporter


BIAS = -0.07
COEF = 193.27732


@click.command()
@click.option('-h', '--host', default='127.0.0.1')
@click.option('-p', '--port', default=12345)
@click.option('-S', '--sensor', default='voltage')
@click.option('-s', '--serial-port', default='/dev/serial0')
@click.option('-b', '--baud-rate', default=9600)
@click.option('-D', '--debug', is_flag=True)
def main(host, port, sensor, serial_port, baud_rate, debug):
    report = SingleSensorReporter(sensor, host, port, debug).report

    if debug:
        debug_print = print
    else:
        debug_print = lambda *a, **kw: None

    with serial.Serial(serial_port, baud_rate) as ser:
        ser.readline()
        for line in ser:
            debug_print(line)
            try:
                line = line.decode().strip()
                rms = float(line.split(',')[-1])
                value = max(rms + BIAS, 0.0) * COEF
                report(value)
            except Exception as e:
                print('ERROR in {line!r}! {e.__class__.__name__}: {e}', file=sys.stderr)


if __name__ == "__main__":
    main()
