import hashlib
from base64 import b64encode, b64decode
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler
import json
import lzma
from socketserver import ThreadingTCPServer
import threading
import time
import traceback

import click
from websocket import WebSocket, enableTrace

from sem.utils import log


def get_accept_key(key):
    if not isinstance(key, bytes):
        key = str(key).encode('latin1')
    accept = hashlib.sha1(key + b'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest()
    return b64encode(accept).decode('latin1')


class WebSocketHandler(BaseHTTPRequestHandler):
    realtime = False

    def getrealtime(self, sock: WebSocket):
        while sock.connected:
            sock.send(json.dumps({'method': 'GetRealTime'}))
            time.sleep(1)

    def on_open(self, sock: WebSocket):
        """To be overridden by a subclass"""

        device_id = self.headers['X-Device-Id']
        log(f'Connection from {device_id}.')
        if self.realtime:
            threading.Thread(target=self.getrealtime, args=(sock,), daemon=True).start()
        while sock.connected:
            try:
                msg = json.loads(sock.recv())
                if msg['method'] == 'DataHistory':
                    data_points = msg['data']['data-points']
                    if isinstance(data_points, str):
                        print('compressed', data_points)
                        data_points = json.loads(lzma.decompress(b64decode(data_points)))
                        print('decompressed', data_points)
                    msg['data'] = f"{len(data_points)} records"
                log(f'{device_id} sent {msg}')
            except Exception:
                log(f'ERROR for {device_id}!')
                log(traceback.format_exc())
        log(f'{device_id} disconnected.')

    def do_GET(self):
        # log('----')
        # log(f'GET from {self.client_address[0]}')
        # log(self.requestline)
        # log(self.headers)
        # log('----')
        if self.headers.get('Connection', '').lower() != 'upgrade':
            log('Bad "Connection" header!')
            return self.send_error(400)
        if self.headers.get('Upgrade', '').lower() != 'websocket':
            log('Bad "Upgrade" header!')
            return self.send_error(400)
        if 'Sec-WebSocket-Key' not in self.headers:
            log('Bad "Sec-WebSocket-Key" header!')
            return self.send_error(400)
        self.send_response(HTTPStatus.SWITCHING_PROTOCOLS)
        self.send_header('Connection', 'Upgrade')
        self.send_header('Upgrade', 'websocket')
        self.send_header('Sec-WebSocket-Accept', get_accept_key(self.headers['Sec-WebSocket-Key']))
        self.end_headers()

        sock = WebSocket()
        sock.sock = self.request
        sock.connected = True

        self.on_open(sock)


@click.command()
@click.option('-p', '--port', type=click.IntRange(1, 0xFFFF), default=4001)
@click.option('-i', '--intf', default='')
@click.option('-r', '--realtime', is_flag=True)
@click.option('-v', '--verbose', is_flag=True)
def main(port, intf, realtime, verbose):
    log('Starting.')
    enableTrace(verbose)
    WebSocketHandler.realtime = realtime
    server = ThreadingTCPServer((intf, port), WebSocketHandler)
    log(f'Listening on {server.server_address[0]}:{server.server_address[1]}')
    server.daemon_threads = True
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log('Ctrl-C')
    server.shutdown()
    server.server_close()
    log('Finished.')


if __name__ == "__main__":
    main()
